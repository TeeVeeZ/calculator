package calculator;

/**Symbol Class
 * 
 * Symbol class was created to assign values of tokens into expressions
 * 
 * 
 * @author zjac311
 *
 */




public enum Symbol {
	
	RIGHT_BRACKET(")"), LEFT_BRACKET("("), ADD("+"), SUBTRACT("-"), MULTIPLY("*"), DIVIDE("/");
	
	
	
	
	
	
}

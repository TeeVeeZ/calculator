package calculator;

import java.util.ArrayList;

/**Stack Class
 * 
 * Stack = data structure that uses Last In First Out (LIFO) system
 * Utilizes push and pop to add and remove data
 * 
 * @author zjac311
 *
 */

public class CalcStack {
	
	private int size = 0;
	  private ArrayList<Entry> entries = new ArrayList<Entry>();

	  /**
	   * CalcStack class constructor
	   * currently takes no parameters
	   */
	  public CalcStack() {
		  /**
		   * will return true if there are no items in stack
		   */
	  }
}

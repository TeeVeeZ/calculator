package calculator;

/**Entry Class
 * 
 * This class was created to create entries that will be used in the code
 * 
 * @author zjac311
 *
 */

public enum Entry {
	ENTRIES [0,1,2,3,4,5,6,7,8,9]
	

}

package calculator;

/**Type class
 * 
 * This class was made to create enumerated types that are going to be used in the code
 * 
 * @author zjac311
 *
 */

public enum Type {
	NUMBER, SYMBOL, STRING, INVALID;

}

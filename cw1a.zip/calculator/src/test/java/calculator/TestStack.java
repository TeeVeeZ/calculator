package calculator;

import static org.junit.jupiter.api.Assertions.*;

/**
 * 
 * This is the code for the junit tests that will be done on the class CalcStack
 * 
 */

import org.junit.jupiter.api.Test;

class TestStack {

	@Test
	void test() {
		CalcStack cs = new CalcStack();
	}

	@Test
	void test() {
		CalcStack cs = new CalcStack();
		assertEquals(cs.size(), 0);
	}
}
